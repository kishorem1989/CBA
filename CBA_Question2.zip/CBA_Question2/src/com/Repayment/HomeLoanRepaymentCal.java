
package com.Repayment;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;



import java.util.HashMap;
import java.util.Map;

public class HomeLoanRepaymentCal 
{
	
	public static void main(String[] args) 
	{
		String strTestCase = "";
    	String strBorrowedAmount="";
		String strYears="";
		String strInterest="";
		// create multimap to store key and values
		Map<String, String> objMap = new HashMap<String, String>();
	    objMap.put("TC1", "25000,10,0.99");
	    objMap.put("TC2", "15000,12,1.99");
	    objMap.put("TC3", "35000,20,2.99");
	    objMap.put("TC4", "15000,30,3.99");
		
	    // Creating Chrome driver instances
        System.setProperty("webdriver.chrome.driver", "\\MyShare\\CBA_Question2\\Driver\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--diable--notifications");
        WebDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("https://www.commbank.com.au");
        System.out.println("Chrome driver launched and Navigated to URL");
        WebElement lnkRepayment = driver.findElement(By.xpath("//*[text() = 'Repayments calculator']"));
        lnkRepayment.click();
        System.out.println("Repayment calculator is available and clicked successfully.");
		int intSize = objMap.size();
		for(int i=1;i<=intSize;i++)
		{
			String strTestCaseValues = objMap.get("TC"+i);
			String[] arrOfStr = strTestCaseValues.split(",", 3);
			strBorrowedAmount = arrOfStr[0];
			strYears = arrOfStr[1];
			strInterest = arrOfStr[2];
	       
	        //Object Creation
	        WebElement txtBorrowAmount = driver.findElement(By.id("amount"));
	        WebElement txtOverYears = driver.findElement(By.id("term"));
	        WebElement lnkInterestRate = driver.findElement(By.id("useProductList"));
	        WebElement txtInterestRate = driver.findElement(By.id("customRate"));
	        WebElement btnCalculate = driver.findElement(By.id("submit"));
	         
	        txtBorrowAmount.clear();
	        txtBorrowAmount.sendKeys(strBorrowedAmount);
	        txtOverYears.clear();
	        txtOverYears.sendKeys(strYears);
	        if(lnkInterestRate.isDisplayed()) 
	        {
	        	lnkInterestRate.click();
	        }
	        txtInterestRate.clear();
	        txtInterestRate.sendKeys(strInterest);
	        if(btnCalculate.isDisplayed())
	        {
	        	btnCalculate.click();
	        }
	        else
	        {
	        	//System.out.println("cal");
	        }
	        //Total amount and Interest component values colloection
	        WebElement eltTotalLoanRepayment = driver.findElement(By.xpath("//span[@data-tid='total-repayment']"));
	        WebElement eltTotalInterestCharged = driver.findElement(By.xpath("//span[@data-tid='total-interest']"));
	        String strTotalLoanRepayment = eltTotalLoanRepayment.getText();
	        String strTotalInterestCharged = eltTotalInterestCharged.getText();
	        System.out.println("For the Test Case :TC"+i+" Borrowed Amount : "+strBorrowedAmount+" ,Years : "+strYears+", and Rate of Interest : "+strInterest);		
	        System.out.println("Total Loan Repayment : "+strTotalLoanRepayment+" ,Total InterestCharged : "+strTotalInterestCharged);
        
		}
        //Closing the Chrome browser
        driver. close();
    }

	
	
}
