package com.ValueExtract;

import java.io.*;  
import java.util.Scanner;   
import  org.apache.poi.hssf.usermodel.HSSFSheet;  
import  org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import  org.apache.poi.hssf.usermodel.HSSFRow;  
public class ValuesExtractfromExcel  
{  
	public static void main(String args[])  
	{  
		try  
		{  
			//declare file name to be create   
			String filename = "D:\\MyShare\\CBA_Question1\\Data\\TestData.xls";  
			//creating an instance of HSSFWorkbook class  
			HSSFWorkbook workbook = new HSSFWorkbook();  
			//invoking creatSheet() method and passing the name of the sheet to be created   
			HSSFSheet sheet = workbook.createSheet("January");   
			//creating the 0th row using the createRow() method  
			HSSFRow rowhead = sheet.createRow((short)0); 
			rowhead.createCell(0).setCellValue("S.No.");  
			rowhead.createCell(1).setCellValue("Customer Name"); 
			
			
			//the file to be opened for reading  
			FileInputStream fis=new FileInputStream("D:\\MyShare\\CBA_Question1\\Data\\q1.test_data");       
			Scanner sc=new Scanner(fis);     
			//returns true if there is another line to read 
			int i = 1;
			while(sc.hasNextLine())  
			{  
				HSSFRow row1 = sheet.createRow((short)i); 
				String strLine = sc.nextLine();
				if(strLine.contains("\""))
				{
					String []splitterString=strLine.split("\"");
				    System.out.println(splitterString[0].trim()+" - "+splitterString[1].trim()); 
				    row1.createCell(0).setCellValue(splitterString[0].trim());  
				    row1.createCell(1).setCellValue(splitterString[1].trim());  
				}	
				i++;
			}  
			sc.close();  
			FileOutputStream fileOut = new FileOutputStream(filename);  
			workbook.write(fileOut);  
			//closing the Stream  
			fileOut.close();  
			//closing the workbook  
			workbook.close();  
			//prints the message on the console  
			System.out.println("Excel file has been generated successfully."); 
		}  
		catch(IOException e)  
		{  
			e.printStackTrace();  
		}  
	}  
}  
